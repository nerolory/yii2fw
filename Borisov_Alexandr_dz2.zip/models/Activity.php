<?php
namespace app\models;

use yii\base\Model;

/**
* Activity класс
*
* Отражает сущность хранимого в календаре события
*/
class Activity extends Model
{
    public $title;
    public $startDay;
    public $endDay;
    public $idAuthor;
    public $body;

    public function attributeLabels()
    {
        return [
            'title'     => 'Название события',
            'startDay'  => 'Дата начала',
            'endDay'    => 'Дата завершения',
            'idAuthor'  => 'ID автора',
            'body'      => 'Описание события'
        ];
    }
}