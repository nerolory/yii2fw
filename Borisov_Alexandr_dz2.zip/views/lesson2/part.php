<h3>фрагмент part</h3>
<h1>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eius, illo?</h1>

<?=Yii::$app->view->renderFile('@app/views/lesson2/parts/fragment.php', ['data'=>date('j.m.Y')]); ?>