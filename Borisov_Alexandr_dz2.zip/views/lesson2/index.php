<?php /** @var $this \yii\base\View */ ?>
<h1>Время</h1>
<?=$time?>

<?= $this->context->renderPartial('part') ?>
